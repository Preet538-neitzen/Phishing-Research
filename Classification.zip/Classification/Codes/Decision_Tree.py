from sklearn import tree
from sklearn.metrics import accuracy_score
import numpy as np
#Reading Dtaset
training_data = np.genfromtxt(r'C:\Users\achyuthk\Desktop\Project\data.csv', delimiter=',', dtype=np.int32)
inputs = training_data[:,:-1]
outputs = training_data[:, -1]

from sklearn.model_selection import train_test_split
training_inputs, testing_inputs, training_outputs,testing_outputs=train_test_split(inputs, outputs, test_size = 0.2, random_state = 0)

classifier = tree.DecisionTreeClassifier()

classifier.fit(training_inputs, training_outputs)

predictions = classifier.predict(testing_inputs)
accuracy = 100.0 * accuracy_score(testing_outputs, predictions)
print(accuracy)


from sklearn.metrics import confusion_matrix
cm = confusion_matrix(testing_outputs, predictions)
#print(cm)


