from sklearn.linear_model import LogisticRegression as lr
from sklearn.metrics import accuracy_score
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.neural_network import MLPClassifier

dataset = pd.read_csv(r'C:\Users\achyuthk\Desktop\Project\data.csv')
X = dataset.iloc[:, :-6].values
y = dataset.iloc[:, -1].values

# Taking care of missing data
from sklearn.impute import SimpleImputer
imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
imputer.fit(X)
X = imputer.transform(X)
#print(X)



from sklearn.model_selection import train_test_split
training_inputs, testing_inputs, training_outputs,testing_outputs= train_test_split(X,
y, test_size = 0.2, random_state = 0)

from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
training_inputs = sc.fit_transform(training_inputs)
testing_inputs = sc.transform(testing_inputs)

classifier = lr(max_iter= 2000)
classifier.fit(training_inputs, training_outputs)

predictions = classifier.predict(testing_inputs)
accuracy = 100.0 * accuracy_score(testing_outputs, predictions)
print('Accuracy % for Logistic Regression : ',accuracy)

###############################################################################