# -*- coding: utf-8 -*-
"""
Created on Wed Jun 16 10:26:55 2021

@author: achyuthk
"""

import numpy
import sklearn
import pandas as pd
from sklearn.model_selection import train_test_split

datatrain = pd.read_csv(r'C:\Users\achyuthk\Desktop\Project\data.csv')
datatrain = datatrain.apply(pd.to_numeric)
datatrain_array = datatrain.values

X_train, X_test, y_train, y_test = train_test_split(datatrain_array[:,:-6],datatrain_array[:,-1],test_size=0.2)

from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)

from sklearn.neural_network import MLPClassifier

mlp = MLPClassifier(hidden_layer_sizes=(10,10),activation='logistic', solver='sgd',learning_rate_init=0.01,max_iter=1800,random_state=7,tol=0.00001)
mlp.fit(X_train, y_train)

print(mlp.score(X_test,y_test))